package com.bank.honest.model.dto;

/**
 * Created by User on 5/10/2018.
 */
public class AdminUsersDTO {
}
