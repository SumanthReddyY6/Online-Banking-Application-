package com.bank.honest.model.entity.enums;

/**
 * Created by User on 2/18/2018.
 */
public enum WalletStatus {

    TRUE, FALSE
}
