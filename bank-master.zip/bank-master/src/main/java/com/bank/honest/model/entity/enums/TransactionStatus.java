package com.bank.honest.model.entity.enums;

/**
 * Created by User on 2/21/2018.
 */
public enum TransactionStatus {
    GOOD, BED
}
